import { KnowledgeGraph } from "@/components/dashboard/KnowledgeGraph";

export default function KnowledgeGraphExample() {
  return (
    <div className="max-w-2xl">
      <KnowledgeGraph />
    </div>
  );
}

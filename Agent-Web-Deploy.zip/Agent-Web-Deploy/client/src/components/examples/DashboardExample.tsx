import DashboardPage from "@/pages/dashboard";

export default function DashboardExample() {
  return <DashboardPage />;
}

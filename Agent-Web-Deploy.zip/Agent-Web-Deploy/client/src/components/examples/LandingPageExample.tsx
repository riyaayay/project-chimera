import LandingPage from "@/pages/landing";

export default function LandingPageExample() {
  return <LandingPage />;
}
